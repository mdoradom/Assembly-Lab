#include <stdio.h>

int asmAVG();

int main() {
	printf("Starting the C program... \n");

	printf("\nAvg: %d\n", asmAVG());

	return 0;
}